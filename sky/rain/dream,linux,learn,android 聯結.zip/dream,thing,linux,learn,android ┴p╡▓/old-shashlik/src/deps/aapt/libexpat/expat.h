// super duper ugly, yes. Android makes silly assumptions.
#include <expat.h>
