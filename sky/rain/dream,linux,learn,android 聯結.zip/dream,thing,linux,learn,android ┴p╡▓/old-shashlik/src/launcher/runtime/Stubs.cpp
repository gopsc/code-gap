#include "jni.h"
#include "JNIHelp.h"
#include "JniInvocation.h"
// 
// 
// int register_android_os_Binder(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_os_Process(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_Bitmap(JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_BitmapFactory(JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_BitmapRegionDecoder(JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Camera(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_CreateJavaOutputStreamAdaptor(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_Graphics(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_Interpolator(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_LayerRasterizer(JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_MaskFilter(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_Movie(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_NinePatch(JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_PathEffect(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_Shader(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_Typeface(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_graphics_YuvImage(JNIEnv* env)
// {
//     return 0;
// }
// 
// 
// int register_com_google_android_gles_jni_EGLImpl(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_com_google_android_gles_jni_GLImpl(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_opengl_jni_EGL14(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_opengl_jni_EGLExt(JNIEnv* env)
// {
//     return 0;
// }
// 
int register_android_opengl_jni_GLES10(JNIEnv* env)
{
    return 0;
}

int register_android_opengl_jni_GLES10Ext(JNIEnv* env)
{
    return 0;
}

int register_android_opengl_jni_GLES11(JNIEnv* env)
{
    return 0;
}

int register_android_opengl_jni_GLES11Ext(JNIEnv* env)
{
    return 0;
}

// int register_android_opengl_jni_GLES20(JNIEnv* env)
// {
//     return 0;
// }
// 
// int register_android_opengl_jni_GLES30(JNIEnv* env)
// {
//     return 0;
// }
// 

int register_android_hardware_Camera(JNIEnv *env)
{
    return 0;
}

int register_android_hardware_camera2_CameraMetadata(JNIEnv *env)
{
    return 0;
}
// 
// int register_android_hardware_SensorManager(JNIEnv *env)
// {
//     return 0;
// }
// 
// int register_android_hardware_SerialPort(JNIEnv *env)
// {
//     return 0;
// }
// 
// int register_android_hardware_UsbDevice(JNIEnv *env)
// {
//     return 0;
// }
// 
// int register_android_hardware_UsbDeviceConnection(JNIEnv *env)
// {
//     return 0;
// }
// 
// int register_android_hardware_UsbRequest(JNIEnv *env)
// {
//     return 0;
// }
// 

int register_android_media_AudioRecord(JNIEnv *env)
{
    return 0;
}

int register_android_media_AudioSystem(JNIEnv *env)
{
    return 0;
}

int register_android_media_AudioTrack(JNIEnv *env)
{
    return 0;
}

int register_android_media_JetPlayer(JNIEnv *env)
{
    return 0;
}

int register_android_media_ToneGenerator(JNIEnv *env)
{
    return 0;
}
// 
// 
// int register_android_util_FloatMath(JNIEnv* env)
// {
//     return 0;
// }
// 
// 
// // ----------------------------------------------------------------
// 
// 
// 
namespace android
{


int register_android_debug_JNITest(_JNIEnv*)
{
    return 0;
}

// int register_android_os_SystemClock(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_util_EventLog(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_util_Log(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_text_format_Time(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_content_AssetManager(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_content_StringBlock(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_content_XmlBlock(_JNIEnv*)
// {
//     return 0;
// }
// 
int register_android_emoji_EmojiFactory(_JNIEnv*)
{
    return 0;
}
// 
// int register_android_text_AndroidCharacter(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_text_AndroidBidi(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_InputDevice(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_KeyCharacterMap(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_SystemProperties(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_Parcel(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_DisplayEventReceiver(_JNIEnv*)
// {
//     return 0;
// }

int register_android_nio_utils(_JNIEnv*)
{
    return 0;
}
// 
// int register_android_view_GraphicBuffer(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_GLES20DisplayList(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_GLES20Canvas(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_HardwareRenderer(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_Surface(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_SurfaceControl(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_SurfaceSession(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_TextureView(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Canvas(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_ColorFilter(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_DrawFilter(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Matrix(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Paint(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Path(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_PathMeasure(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Picture(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_PorterDuff(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Rasterizer(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Region(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_SurfaceTexture(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_graphics_Xfermode(_JNIEnv*)
// {
//     return 0;
// }

int register_android_graphics_pdf_PdfDocument(_JNIEnv*)
{
    return 0;
}
// 
// int register_android_database_CursorWindow(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_database_SQLiteConnection(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_database_SQLiteGlobal(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_database_SQLiteDebug(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_Debug(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_FileObserver(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_FileUtils(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_MessageQueue(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_SELinux(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_Trace(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_os_UEventObserver(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_net_LocalSocketImpl(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_net_NetworkUtils(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_net_TrafficStats(_JNIEnv*)
// {
//     return 0;
// }

int register_android_net_wifi_WifiNative(_JNIEnv*)
{
    return 0;
}
// 
// int register_android_os_MemoryFile(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_com_android_internal_os_ZygoteInit(_JNIEnv*)
// {
//     return 0;
// }

int register_android_media_RemoteDisplay(_JNIEnv*)
{
    return 0;
}
// 
// int register_android_opengl_classes(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_server_NetworkManagementSocketTagger(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_server_Watchdog(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_ddm_DdmHandleNativeHeap(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_backup_BackupDataInput(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_backup_BackupDataOutput(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_backup_FileBackupHelperBase(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_backup_BackupHelperDispatcher(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_app_backup_FullBackup(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_app_ActivityThread(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_app_NativeActivity(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_InputChannel(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_InputEventReceiver(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_InputEventSender(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_InputQueue(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_KeyEvent(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_MotionEvent(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_PointerIcon(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_view_VelocityTracker(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_content_res_ObbScanner(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_content_res_Configuration(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_android_animation_PropertyValuesHolder(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_com_android_internal_content_NativeLibraryHelper(_JNIEnv*)
// {
//     return 0;
// }
// 
// int register_com_android_internal_net_NetworkStatsFactory(_JNIEnv*)
// {
//     return 0;
// }
// 
// 
// 
}; // namespace android

