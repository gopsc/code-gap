struct InputArgs{
  int argc;
  char **argv;
};
void StartAppThread(InputArgs &);
