#include <../include/png.h>

typedef struct png_struct_def png_struct;

typedef size_t png_size_t;
#define png_sizeof(x) sizeof(x)
