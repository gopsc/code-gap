




 # include  < stdio.h  >

 # include  < stdlib.h  >




 int main ()


  {


 system ( "/opt/? deamon   >   /opt/TxL/trees/0/TxL_deamon.note" );


  }
