



/*

 use different include file

  to let seed can be run on stm32 maybe

*/



 int gop_wait (  double that_time  )


  {



/*

 maybe use timer alarm

 could use in stm32, arduino

 diy circle

*/


 usleep ( that_time * 1000000 );


  }