



int SystemInit() {

	// ok i wander what's going on with this and :D

    return 1;}
