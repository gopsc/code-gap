









/*

 the mcu of kylin mini board is  stm32f103rct6





 this is the base head file

 and don't know where it come


 and it won't be nessensary
 
*/



/*

 #include "./startup_stm32f10x_hd.s"

*/










/*

 this is a packge of ways and leaves

 use in many source

*/


/*

 #include <stm32f10x.h>

*/












/*

 it is added for things

 nessensary


 and use to add by  "stm32f10x.h"

*/


# include "../sister/sister_init.h"













// this is head files


/*

 # include  "../things/varilables.h"

*/


 # include  "../varilables.h"











// this is files for acrossing stm32 in the future


// #include "../sister/time.h"

// #include "../sister/gpio.h"



