


// this is the varilables for stm32

// # include <head/varilables.h>



/*

 int  mode_gpio_out  =  GPIO_Mode_Out_PP;

 int  speed_gpio     =  GPIO_Speed_50MHz;
 
 */

