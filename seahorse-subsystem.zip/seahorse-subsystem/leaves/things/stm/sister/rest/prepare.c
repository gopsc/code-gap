

















/*

 char is meanned charactor in gcc

 but it seems like number there



 maybe move it to hope
 
 
 maybe move to about



 let it changed with weather
 
*/


/*

 unsigned short number_count_sleep

*/


/*

 void * number_count_wait;
 
*/

















/*

 prepare the system tick and the count number

*/



/*

int init_sleep() {

*/


/*

 int prepare_wait ()

*/


 void  *  prepare_rest  ()
 
  {


/*

 �oַ ЪϢ֮�A��

 ��

*/









/*

 this is a specificate

*/


/*

 SysTick->CTRL &= (1 << 2);

*/


 SysTick  ->  CTRL   &=   (  1 << 2  );




















/*

 there's two lines of commands in the delay loop

 .. 72 MHz  /  8   =   1 000 000 Hz

      stm32f103 -- 9
	  
	
	
 maybe
 
 
 maybe it's a time re-computer

*/





/*


 number_count_wait  =  malloc  (  sizeof ( unsigned short )  );
 
*/


 that . about . dream . rest   =   malloc  (  sizeof ( unsigned short )  );







 
 /*
 
 number_count_sleep = 9;
 
 */


/*

  *  (  unsigned short  )  number_count_sleep  =  9;

*/


  *  (  unsigned short  )  that . about . dream . rest   =   9;
 
 
 
 
 
 
 
 
  }