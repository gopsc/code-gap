



 struct hopes_sound


  {






 int    rate;

 int    channels;

 int    snake;





  };


