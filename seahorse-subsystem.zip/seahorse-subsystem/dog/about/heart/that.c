
int about_cpu () {

    about_CPU_rate ();
    about_CPU_temperature ();
    about_CPU_cores ();
    about_CPU_frequency ();

    return 1;}