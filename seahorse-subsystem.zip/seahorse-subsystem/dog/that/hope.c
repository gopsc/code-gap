






/*

 the flags

 used in gop_about in watchdog/information/build.h -> struct gopi_about

*/






 struct hope_dog


  {



  
  /*

 use it when it is about

*/


/*

 char symbol [ 16 ];

*/









/*

 about system

*/


 int  main;

 int  deamon;

 
 
 
 
 
 
 
/*
 
 about dog
 
*/
 
 
 int  dog;
 
 
 
 
 
 
/*

 they run after dog

*/

 int  dog_start;
 
 int  dog_show;

 
 
 
 
 
 
/*
 
 about spider
 
*/
 
 
 int  spider_male;

 int  spider_female;

 
 
 
 
 
/*

 about voice 
 
*/


 int  voice;
 
 int  voice_show;
 
 int  voice_save;


 
 
 
 
  };
