
int load_symbol () {


    output_print ( "string", "Load symbol...\n" );


// The flag of 'NEXT'

    strcpy (  gop_configurations . symbol_next,  "\n\n"                                ); 
    strcat (  gop_configurations . symbol_next,  "|\\  |  +--  \\ /  -----  B \n"      ); 
    strcat (  gop_configurations . symbol_next,  "| \\ |  |--   X     |    Y: \n"      );
    strcat (  gop_configurations . symbol_next,  "|  \\|  +--  / \\    |    gap \n\n"  );


    return 1;}