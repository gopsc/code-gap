
























 i really don't know what it is i typed

 & it is as hope ^-^

 and it haven't have any promise to anyone yet

 but u should do things u promise to others





# before two thousand and ninteen




# gop seed


it is a program with my learning,
maybe it's not meaningful
but it's always just meaningful to me..


just use gcc now

 cd TxL

 gcc  seed/that.c  -o  ./?

 ./?

then u can c






/*

 first

     cd ./TxL


 it's a beginning with this script

     bash ./seed/box/Linux/seed.sh


 then it will make a file named '?'


     ./?


 then try again


     ./?


  ok , just like that... :D
  then, you can see

*/





# sky

the resource and hopes found

they've  grow little bigger


# river

all the tools and softwares used

and forget it

this river is for save the code before as the title

and this is awesome


# tree

this is a dream and i don't know if this could finished
