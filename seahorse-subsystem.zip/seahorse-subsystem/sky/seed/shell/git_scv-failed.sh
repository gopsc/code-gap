
#!/bin/bash

export GIT_SSL_NO_VERIFY=1


