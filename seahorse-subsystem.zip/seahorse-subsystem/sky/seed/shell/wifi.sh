

#!/bin/bash

sudo iwconfig wlan0 essid "ChinaTelecom-EDU2.4G"

sudo dhclient wlan0
