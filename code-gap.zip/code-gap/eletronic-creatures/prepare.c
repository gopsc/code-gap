/*

eletronic-creatures,

prepare.fst


eletronic-creatures, prepare.fst,  unit,  check-test

eletronic-creatures, prepare.fst,  unit,  check


eletronic-creatures, prepare.fst,  mode, test,  check

eletronic-creatures, prepare.fst,  mode, instant,  check

eletronic-creatures, prepare.fst,  mode, package,  check


eletronic-creatures, prepare.fst,  code,  start


eletronic-creatures, prepare.fst,  mode, package,  check

eletronic-creatures, prepare.fst,  mode, instant,  check

eletronic-creatures, prepare.fst,  mode, test,  check


eletronic-creatures, prepare.fst,  unit,  check

*/













/*

eletronic-creatures

prepare.fst,

unit,  check-test

*/






#ifdef unitElements_sections___fst_eletronicCreatures__prepare

#ifdef unitElements__test


#ifndef unitElements_sectionsTest___fst_eletronicCreatures__prepare

#define unitElements_sectionsTest___fst_eletronicCreatures__prepare


#undef unitElements_sections___fst_eletronicCreatures__prepare


#endif


#endif

#endif

















/*

eletronic-creatures

prepare.fst,

unit,  check

*/






#ifndef unitElements_sections___fst_eletronicCreatures__prepare

#define unitElements_sections___fst_eletronicCreatures__prepare














/*

eletronic-creatures

prepare.fst,

mode, test,  check

*/






#ifdef unitElements__test

#ifdef unitElements_hardware___computer_common

#ifdef unitElements_test___fst_eletronicCreatures__prepare


#ifndef unitElements_language___c_common

#define unitElements_language___c_common

#endif


#ifndef unitElements_instant

#define unitElements_instant

#endif


#endif

#endif

#endif













/*

e

*/






#ifdef unitElements__instant

#ifdef unitElements_hardware___computer_common

#ifdef unitElements_language___c_common


#ifndef unitElements__package

#define unitElements__package

#endif


//#include


#endif

#endif

#endif















/*

eletronic-creatures

prepare.fst,

mode, package,  ckeck

*/






#ifdef unitElements__package

#ifdef unitElements_hardware___computer_common

#ifdef unitElements_language___c_common














/*

eletronic-creatures

prepare.fst,

code,  start

*/






//#include "./../eletronic-creatures/tensorflow/prepare.c"














/*

eletronic-creatures,

prepare.fst,

mode, package,  check

*/






#endif

#endif

#endif














/*

eletronic-creatures,

prepare.fst,

mode, instant,  check

*/






#ifdef unitElements__instant

#ifdef unitElements_hardware___computer_common

#ifdef unitElements_language___c_common


#ifdef unitElements__package

#undef unitElements__package


#endif

#endif

#endif














/*

eletronic-creatures

prepare.fst,

mode, test,  check

*/






#ifdef unitElements__test

#ifdef unitElements_hardware___computer_common

#ifdef unitElements_test___fst_eletronicCreatures__prepare


#ifdef unitElements_language___c_common

#undef unitElements_language___c_common

#endif


#ifdef unitElements__instant

#undef unitElements__instant

#endif


#endif

#endif

#endif














/*

eletronic-creatures

prepare.fst,

unit,  check

*/






#endif


