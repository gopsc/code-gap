



struct   hope_sound


{






void  *   rate;

void  *   snake;







};


