










struct   that_sound


{










/*

char   type_corde  [ 32 ]   =   "blank";

*/







/*

char   path_sound   [ 128 ];

*/











/*

int   number_listen   =   1;

*/




void  *   number_listem;






/*


  ------<--------1234...-------------


*/







double    result_sound   [ 200 ] [ 512 ];

/*

                         [ num ] [  t  ]

*/














double   result_ft    [ 200 ] [ 512 ];

/*

                      [  t  ] [  w  ]

*/








double   result_listen   [ 100 ] [ 512 ] [ 200 ];

/*

                         [ num ] [  w  ] [  t  ]

*/








};



