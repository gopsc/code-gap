
























 i really don't know what it is i typed

 & it is as hope ^-^

 and it haven't have any promise to anyone yet

 but u should do things u promise to others

