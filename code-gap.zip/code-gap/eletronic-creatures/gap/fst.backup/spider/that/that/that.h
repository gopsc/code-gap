







struct that_spider


{








void  * *   how;




/*

time_t

*/


void  *   time;







void  * *   descriptor;


void  * *   connection;









void  * *   address;

void  * *   port;






void  *   command;









void  * *   update;




void  *   step_update;

void  *   flag_update;










/*

 ----<-----...43210-----------

*/


/*

void  *   video;

void  *   audio;

*/









void  *   about;





/*

void  *   note;

*/





};




