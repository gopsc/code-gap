






struct that_lake_spider


{




void *  symbol;





/*

char ip [ 32 ] [ 3 ] [ 1024 ];

*/


void  *  *   address;


void  *   number;





};







