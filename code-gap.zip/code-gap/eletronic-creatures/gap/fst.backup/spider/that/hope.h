
















struct   hope_spider


{











void  *   address;


void  *   port_to;


void  *   port_this;






void  *   symbol_next;


void  *   step_connection;


void  *   size_update;







};
















