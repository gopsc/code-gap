







void  *   end_fst_dog ()

{

drop_fst_leaves_lake  (  "that,fst,dog,main"  );

drop_fst_leaves_lake  (  "that,fst,dog,circle"  );


drop_fst_leaves_lake  (  "that,fst,dog"  );

drop_fst_leaves_lake  (  "that,fst,dog,start"  );

drop_fst_leaves_lake  (  "that,fst,dog,show"  );


drop_fst_leaves_lake  (  "that,fst,dog,female"  );

drop_fst_leaves_lake  (  "that,fst,dog,male"  );


drop_fst_leaves_lake  (  "that,fst,dog,voice"  );

drop_fst_leaves_lake  (  "that,fst,dog,show"  );


drop_fst_leaves_lake  (  "that,fst,dog,symbol"  );



return   fish_fst_leaves_lake   (  "that,fst,leaves,lake,existence,yes"  );

}







