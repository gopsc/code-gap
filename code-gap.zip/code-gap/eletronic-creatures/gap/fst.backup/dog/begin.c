







void  *   begin_fst_dog ()

{

write_fst_leaves_lake  (  "that,fst,dog,main",  "no"  );

write_fst_leaves_lake  (  "that,fst,dog,circle",  "no"  );


write_fst_leaves_lake  (  "that,fst,dog",  "no"  );

write_fst_leaves_lake  (  "that,fst,dog,start",  "no"  );

write_fst_leaves_lake  (  "that,fst,dog,show",  "no"  );


write_fst_leaves_lake  (  "that,fst,dog,female",  "no"  );

write_fst_leaves_lake  (  "that,fst,dog,male",  "no"  );


write_fst_leaves_lake  (  "that,fst,dog,voice",  "no"  );

write_fst_leaves_lake  (  "that,fst,dog,show",  "no"  );


write_fst_leaves_lake  (  "that,fst,dog,symbol",  "waitting"  );



return   fish_fst_leaves_lake  (  "that,fst,leaves,lake,existence,yes"  );

}







