SCOOP LIBRARY
project hosted on google code:
check latest version and documentation here:
https://code.google.com/p/arduino-scoop-cooperative-scheduler-arm-avr/
