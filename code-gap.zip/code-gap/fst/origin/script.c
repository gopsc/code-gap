

#ifndef unitElements_sections___fst_origin__scripts

#define unitElements_sections___fst_origin__scripts




#ifdef unitElements__instant

#ifdef unitElements_hardware___computer_common

#ifdef unitElements_language___c_script


#ifndef unitElements__package

#define unitElements__package

#endif


#include "./../../roots/threads/prepare.bases"


#include "./../../roots/lakes/prepare.bases"


#include "./../../branches/lakes/prepare.bases"


#include "./../../branches/dreams/seeds/begin.bases"


#endif

#endif

#endif




#ifdef unitElements__package

#ifdef unitElements_hardware___computer_common

#ifdef unitElements_language___c_script


type_variable___prepare_void

function_origin__script

(


type_variable___prepare_void

that_number_length__argumentCount,


type_variable__prepare_void *

that_pointer_vector__argumentVector


)

{




#ifdef unitElement__test


if

(

( type_variable__prepare_void )

that_number_length__argumentCount

==

( type_variable__prepare_void )

note_pointer_vector__null

)

{

return

( type_variable__prepare_void )

note_pointer_vector__null;

}


if

(

( type_variable__prepare_void ) ( type_variable__prepare_void * )

that_pointer_vector__argumentVector

==

( type_variable__prepare_void )

note_pointer_vector__null

)

{

return

( type_variable__prepare_void )

note_pointer_vector__null;

}




if

(

( type_variable__prepare_void )

that_number_length__argumentCount

==

( type_variable__prepare_void )

note_pointer_vector__null

)

{

return

( type_variable__prepare_void )

note_pointer_vector__null;

}


/*

if

(

( type_variable_,prepare_void * )

that_pointer_vector__argumentVector

==

( type_variable__prepare_void )

note_pointer_vector__null

)

{

return

( type_variable__prepare_void )

note_pointer_vector__null;

}

*/


#endif























// ( that_fst_roots_threads_prepare_waters )

that_fst_branches_lakes_prepare

=

( that_fst_roots_threads_prepare_waters )

that_fst_roots_lakes_prepare;









that_ways___fst_branches__dreams_seeds___begin

(




( that_fst_roots_threads_prepare_waters * )

& // ( that_fst_roots_threads_prepare_waters )


(


// ( that_fst_roots_threads_prepare_waters )

that_fst_branches_lakes_prepare


),




( that_fst_roots_threads_prepare_waters )

( that_fst_roots_threads_prepare_stones * )


"fst,branches,flowers,begin",




( that_fst_roots_threads_prepare_waters )

that_silts_lengths__moons,




( that_fst_roots_threads_prepare_waters * )

that_waters_sources__moons




);

























return


( that_fst_roots_threads_prepare_waters )

that_fst_roots_lakes_prepare;









}


#endif

#endif

#endif




#ifdef unitElements__instant

#ifdef unitElements_hardware___computer_common

#ifdef unitElements_language___c_script


#ifdef unitElements__package

#undef unitElements__package


#endif

#endif

#endif




#endif

