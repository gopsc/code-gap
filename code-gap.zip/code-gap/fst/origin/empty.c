

#ifndef unitElements_sections___fst_origin__empty

#define unitElements_sections___fst_origin__empty




#ifdef unitElements__package

#ifndef unitElements__test


#ifndef unitElements_hardware___computer_common

#define unitElements__test

#endif


#ifndef unitElements_language___c_common

#define unitElements__test

#endif


#endif

#endif




#ifdef unitElements__test


type_variable__prepare_void

function_origin__script

()

{}


#endif




#ifdef unitElements__package


#ifdef unitElements__test

#undef unitElements__test

#endif


#endif




#endif


