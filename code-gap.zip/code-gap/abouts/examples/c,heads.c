/*

#include <stdlib.h>
                               // for null
                               //
                               // for __uint8_t, __uint16_t, __uint32_t, __uint64_t
                               //
                               // for malloc(), realloc(), free()



#include <stdio.h>
                              // for null
                              //
                              // for __int8_t, __int16_t, __int32_t, __int64_t
                              // for __uint8_t, __uint16_t, __uint32_t, __uint64_t
                              //
                              // for int8_t, int16_t, int32_t, int64_t
                              // for uint8_t, uint16_t, uint32_t, uint64_t
                              //
                              // for printf()
                              //
                              // for remove()
                              //
                              // for type FILE
                              // for fopen()
                              // for fclose()
                              // for fgets()
                              // for fprintf()









#include <math.h>
                               // for pi
                               // for trigonometric function



#include <time.h>
                             // for time(NULL)



#include <signal.h>
                               // for check_deamon() ->
                               // for tcp block out



#include <fcntl.h>
                              // for network socket









#include <memory.h>
                            // for null
                            // for memset()



#include <dirent.h>
                              // for dirent



#include <ifaddrs.h>
                               // for network socket



#include <pthread.h>
                                // for thread









#include <arpa/inet.h>
                                    // for network



#include <unistd.h>









#include <sys/stat.h>
                                  // for struct stat
                                  // for lstat()
                                  // for S_ISDIR()
                                  // for S_ISREG()
                                  //
                                  // for mkdir()
                                  // for S_IRWXU, S_IRWXG, S_IROTH, S_IXOTH



#include <sys/time.h>
                                   // for note_save() -> gettimeofday()



#include <sys/types.h>
                                    // for check_deamon() ->



#include <sys/param.h>
                                    // for ...



#include <sys/socket.h>
                                    // for network -> socket









#include <arduino.h>



#include <Wire.h>



#include <spi.h>









#include <wiringpi.h>

*/