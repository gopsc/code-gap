

if [  $unitElements_hardware___emulator  ]; then

unitElements_hardware___computer_common='yes'

unitElements_hardware___computer_emulation='yes'

fi


