

if [  $unitElements_hardware___computer  ]; then

unitElements_hardware___computer_common='yes'

fi


