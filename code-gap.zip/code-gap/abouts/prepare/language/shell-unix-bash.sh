

if [  $unitElements_language___shell_unix_bash  ]; then


unitElements_language___shell_unix_common='yes'


fi


